HOW TO MAKE THE BINARY EXECUTABLE ON MACOS:

After unzipping the file, you will need to set the executable permission for the CERBERUS-SOFTWARE-BOT_CLI binary. To do this, open the Terminal and run the following commands:

1. Navigate to the directory where you unzipped the files:
   cd path/to/unzipped/folder

2. Set the executable permission:
   chmod +x CERBERUS-SOFTWARE-BOT_CLI

Now, you can run the CERBERUS-SOFTWARE-BOT_CLI binary on your MacOS system.
